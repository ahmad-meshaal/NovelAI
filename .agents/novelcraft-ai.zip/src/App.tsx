/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Type, 
  FileText, 
  Download, 
  Sparkles, 
  AlignLeft, 
  AlignCenter, 
  AlignRight, 
  AlignJustify,
  Bold,
  Italic,
  Settings2,
  ChevronDown,
  Loader2,
  Undo2,
  Redo2,
  Plus,
  Lock,
  Unlock,
  Menu,
  X,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import html2pdf from 'html2pdf.js';
import { generateNovelStream } from './lib/gemini';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Helper for Tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const FONTS = [
  { name: 'Inter', value: 'var(--font-sans)', label: 'Sans' },
  { name: 'Georgia', value: 'Georgia, serif', label: 'Classic Serif' },
  { name: 'Amiri', value: '"Amiri", serif', label: 'Amiri (Arabic)' },
  { name: 'Noto Sans Arabic', value: '"Noto Sans Arabic", sans-serif', label: 'Noto Arabic' },
  { name: 'JetBrains Mono', value: 'var(--font-mono)', label: 'Mono' },
];

const FONT_SIZES = [12, 14, 16, 18, 20, 24, 28, 32];

export default function App() {
  const [input, setInput] = useState('');
  const [content, setContent] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [fontSize, setFontSize] = useState(18);
  const [fontFamily, setFontFamily] = useState(FONTS[2].value);
  const [alignment, setAlignment] = useState<'left' | 'center' | 'right' | 'justify'>('right');
  const [isBold, setIsBold] = useState(false);
  const [isItalic, setIsItalic] = useState(false);
  const [isEditable, setIsEditable] = useState(true);
  const [language, setLanguage] = useState<'ar' | 'en'>('ar');
  const [lineHeight, setLineHeight] = useState(1.8);
  const [progress, setProgress] = useState(0);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  const editorRef = useRef<HTMLDivElement>(null);

  // Simulated progress bar logic - making it slower and more granular for long 6k+ char generation
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isGenerating) {
      setProgress(0);
      interval = setInterval(() => {
        setProgress((prev) => {
          if (prev < 20) return prev + 0.8; // Fast start
          if (prev < 85) return prev + 0.15; // Slow long middle for 6000 chars
          if (prev < 98) return prev + 0.05; // Very slow crawl at end
          return prev;
        });
      }, 500);
    } else {
      setProgress(100);
      const timer = setTimeout(() => setProgress(0), 500);
      return () => clearTimeout(timer);
    }
    return () => clearInterval(interval);
  }, [isGenerating]);

  // Auto-close sidebar on mobile
  useEffect(() => {
    const checkMobile = () => {
      if (window.innerWidth < 768) {
        setIsSidebarOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleGenerate = async () => {
    if (!input.trim()) return;
    setIsGenerating(true);
    if (window.innerWidth < 768) setIsSidebarOpen(false);
    setContent(''); // Clear previous
    setProgress(0);
    
    try {
      const stream = generateNovelStream(input, language);
      let fullContent = '';
      for await (const chunk of stream) {
        fullContent += chunk;
        setContent(fullContent);
      }
    } catch (error) {
      alert(language === 'ar' ? 'حدث خطأ أثناء التوليد' : 'Error generating content');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDirectFormat = () => {
    if (!input.trim()) return;
    
    const lines = input.split('\n').filter(line => line.trim() !== '');
    if (lines.length === 0) return;

    // Pattern for detecting chapters: "الفصل الأول", "Chapter 1", "البارت الأول", etc.
    // Enhanced regex to catch more variations
    const chapterRegex = /^(الفصل|البارت|فصل|القسم|الجزء|Chapter|Part|Section|Ch\.|Pt\.)\s*((\d+)|([\u0621-\u064A]+))/i;

    let html = `<h1>${lines[0]}</h1>`;
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      // If line is short and matches chapter pattern OR is very short compared to surrounding lines
      if (chapterRegex.test(line) || (line.length < 40 && line.length > 0)) {
        html += `<h2>${line}</h2>`;
      } else {
        html += `<p>${line}</p>`;
      }
    }
    
    setContent(html);
  };

  const handleExportPDF = async () => {
    if (!editorRef.current) return;
    
    setIsGenerating(true); 
    
    try {
      const element = editorRef.current;
      
      // Temporary clone to clean up for PDF
      const worker = html2pdf();
      const opt = {
        margin: [20, 20, 25, 20] as [number, number, number, number],
        filename: 'novel.pdf',
        image: { type: 'jpeg' as const, quality: 1 },
        html2canvas: { 
          scale: 1.5,
          useCORS: true, 
          letterRendering: true,
          backgroundColor: '#ffffff',
          scrollY: 0,
          windowWidth: document.documentElement.offsetWidth
        },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' as const, compress: true },
        pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
      };

      await new Promise(resolve => setTimeout(resolve, 1000));
      await worker.set(opt).from(element).save();
    } catch (error) {
      console.error("PDF Export Error:", error);
      alert(language === 'ar' 
        ? 'حدث خطأ أثناء تصدير ملف PDF. النص قد يكون طويلاً جداً.' 
        : 'PDF Export failed. Content might be too large.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExportHTML = () => {
    if (!content) return;
    const htmlContent = `<!DOCTYPE html>
<html lang="${language}" dir="${language === 'ar' ? 'rtl' : 'ltr'}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novel - ${language === 'ar' ? 'روايتي' : 'My Novel'}</title>
    <link href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Noto+Sans+Arabic:wght@400;700&family=Inter:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root { 
            --bg: #FDFCFB; 
            --text: #1a1a1a; 
            --primary: #c2410c; 
            --card: #ffffff;
            --border: #eaeaea;
        }
        @media (prefers-color-scheme: dark) {
            :root {
                --bg: #121212;
                --text: #e5e5e5;
                --card: #1e1e1e;
                --border: #333333;
            }
        }
        body { 
            font-family: 'Amiri', serif; 
            background: var(--bg);
            color: var(--text);
            margin: 0;
            padding: 0;
            line-height: ${lineHeight};
            transition: background 0.3s, color 0.3s;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 80px 24px;
            min-height: 100vh;
        }
        .progress-bar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--primary);
            z-index: 1000;
            width: 0%;
            transition: width 0.1s linear;
        }
        h1 { 
          text-align: center; 
          font-size: clamp(2.5rem, 8vw, 4.5rem); 
          border-bottom: 3px double var(--border); 
          padding-bottom: 0.5em; 
          margin-bottom: 2em;
          font-family: 'Amiri', serif;
        }
        h2 { 
          text-align: center; 
          color: var(--primary); 
          margin-top: 5em; 
          font-size: clamp(1.8rem, 5vw, 2.8rem); 
          font-family: 'Amiri', serif;
          border-top: 1px solid var(--border);
          padding-top: 2em;
        }
        p { 
          margin-bottom: 2.5em; 
          text-indent: 2em; 
          text-align: justify; 
          font-size: ${fontSize}px;
          hyphens: auto;
        }
        
        .controls {
            position: fixed;
            bottom: 32px;
            right: 32px;
            background: var(--card);
            padding: 12px 20px;
            border-radius: 50px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
            display: flex;
            gap: 15px;
            z-index: 100;
            border: 1px solid var(--border);
            align-items: center;
        }
        .btn { 
          border: none; 
          background: var(--border); 
          cursor: pointer; 
          color: var(--text); 
          padding: 10px 18px; 
          border-radius: 25px; 
          font-weight: bold; 
          font-size: 14px;
          transition: all 0.2s;
        }
        .btn:hover {
          filter: brightness(0.9);
          transform: translateY(-2px);
        }
        
        @media (max-width: 600px) {
            .container { padding: 40px 16px; }
            h1 { font-size: 2.2rem; }
            p { font-size: calc(${fontSize}px * 0.9) !important; text-indent: 1.2em; }
            .controls { bottom: 16px; right: 16px; left: 16px; justify-content: center; transform: scale(0.9); }
        }
    </style>
</head>
<body>
    <div class="progress-bar" id="pb"></div>
    <div class="container">${content}</div>
    <div class="controls">
        <button class="btn" onclick="adjustSize(2)">Font +</button>
        <button class="btn" onclick="adjustSize(-2)">Font -</button>
        <button class="btn" onclick="window.print()">Print</button>
    </div>
    <script>
        window.onscroll = function() {
            let winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            let height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            let scrolled = (winScroll / height) * 100;
            document.getElementById("pb").style.width = scrolled + "%";
        };
        let currentSize = ${fontSize};
        function adjustSize(delta) {
            currentSize += delta;
            document.querySelectorAll('p').forEach(p => p.style.fontSize = currentSize + 'px');
        }
    </script>
</body>
</html>`;
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'novel.html';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-[#FDFCFB] text-[#1a1a1a] flex flex-col selection:bg-orange-100">
      {/* Header / Toolbar */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200 px-4 sm:px-6 py-3 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-2 sm:gap-3">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-gray-100 rounded-lg md:hidden"
          >
            {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <div className="bg-orange-600 p-2 rounded-lg hidden sm:block">
            <FileText className="text-white w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <h1 className="font-serif font-bold text-lg sm:text-xl tracking-tight hidden xs:block">NovelCraft</h1>
        </div>

        <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto no-scrollbar mx-2 sm:mx-4 flex-1 justify-center sm:justify-start">
          <select 
            value={fontFamily} 
            onChange={(e) => setFontFamily(e.target.value)}
            className="text-xs sm:text-sm border-none bg-gray-50 rounded-md px-1 sm:px-2 py-1 outline-none hover:bg-gray-100 transition-colors cursor-pointer min-w-[80px]"
          >
            {FONTS.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
          </select>

          <div className="h-6 w-px bg-gray-200 mx-1 hidden sm:block" />

          <select 
            value={fontSize} 
            onChange={(e) => setFontSize(Number(e.target.value))}
            className="text-xs sm:text-sm border-none bg-gray-50 rounded-md px-1 sm:px-2 py-1 outline-none hover:bg-gray-100 transition-colors cursor-pointer"
          >
            {FONT_SIZES.map(s => <option key={s} value={s}>{s}px</option>)}
          </select>

          <div className="h-6 w-px bg-gray-200 mx-1 hidden xs:block" />

          <div className="flex items-center bg-gray-50 rounded-md p-0.5 hidden sm:flex">
            {[
              { id: 'left', icon: AlignLeft },
              { id: 'center', icon: AlignCenter },
              { id: 'right', icon: AlignRight },
              { id: 'justify', icon: AlignJustify }
            ].map(({ id, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setAlignment(id as any)}
                className={cn(
                  "p-1.5 rounded transition-all",
                  alignment === id ? "bg-white shadow-sm text-orange-600" : "text-gray-400 hover:text-gray-600"
                )}
              >
                <Icon size={14} />
              </button>
            ))}
          </div>

          <div className="h-6 w-px bg-gray-200 mx-1 hidden sm:block" />

          <button
            onClick={() => setIsBold(!isBold)}
            className={cn("p-1.5 rounded", isBold ? "bg-orange-100 text-orange-600" : "text-gray-400 hover:bg-gray-100")}
          >
            <Bold size={14} />
          </button>
          <button
            onClick={() => setIsItalic(!isItalic)}
            className={cn("p-1.5 rounded", isItalic ? "bg-orange-100 text-orange-600" : "text-gray-400 hover:bg-gray-100")}
          >
            <Italic size={14} />
          </button>

          <div className="h-6 w-px bg-gray-200 mx-1 hidden sm:block" />

          <button
            onClick={() => setIsEditable(!isEditable)}
            title={isEditable ? (language === 'ar' ? 'قفل التعديل' : 'Lock Editing') : (language === 'ar' ? 'فتح التعديل' : 'Enable Editing')}
            className={cn(
              "p-1.5 rounded flex items-center gap-2 text-sm font-medium transition-all",
              isEditable 
                ? "text-green-600 hover:bg-green-50" 
                : "bg-red-50 text-red-600 border border-red-100 shadow-sm"
            )}
          >
            {isEditable ? <Unlock size={14} /> : <Lock size={14} />}
            <span className="hidden xl:inline">
              {isEditable 
                ? (language === 'ar' ? 'تعديل نشط' : 'Editing On') 
                : (language === 'ar' ? 'تم القفل' : 'Locked')}
            </span>
          </button>
        </div>

        <div className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={handlePrint}
            title={language === 'ar' ? 'طباعة' : 'Print'}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-all hidden sm:block"
          >
            <Settings2 size={18} />
          </button>
          <button
            onClick={handleExportHTML}
            disabled={!content}
            title={language === 'ar' ? 'حفظ كصفحة ويب (HTML)' : 'Save as Web Page (HTML)'}
            className="p-2 text-gray-400 hover:text-orange-600 hover:bg-orange-50 rounded-full transition-all"
          >
            <Globe size={18} />
          </button>
          <button
            onClick={handleExportPDF}
            disabled={!content || isGenerating}
            className="bg-[#1a1a1a] text-white px-3 sm:px-4 py-2 rounded-full text-xs sm:text-sm font-medium flex items-center gap-1 sm:gap-2 hover:bg-black transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
          >
            <Download size={14} sm:size={16} />
            <span className="hidden md:inline">{language === 'ar' ? 'تحميل PDF' : 'Download PDF'}</span>
          </button>
        </div>
      </header>

      <main className="flex-1 flex flex-col md:flex-row h-[calc(100vh-64px)] overflow-hidden relative">
        {/* Left Sidebar: Input Controls */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.aside 
              initial={{ x: language === 'ar' ? 300 : -300 }}
              animate={{ x: 0 }}
              exit={{ x: language === 'ar' ? 300 : -300 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className={cn(
                "absolute md:relative z-40 h-full w-[280px] sm:w-80 border-r border-gray-100 bg-white p-4 sm:p-6 flex flex-col gap-4 sm:gap-6 shadow-2xl md:shadow-none",
                language === 'ar' ? 'right-0 border-l border-r-0' : 'left-0'
              )}
            >
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-gray-400">
                  {language === 'ar' ? 'فكرة الرواية أو التلخيص' : 'Novel Concept or Summary'}
                </label>
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  dir={language === 'ar' ? 'rtl' : 'ltr'}
                  placeholder={language === 'ar' ? 'اكتب ملخصاً بسيطاً أو فكرة لتبدأ، سأحاول كتابة فصول طويلة ومفصلة...' : 'Enter a brief summary or idea to start, I will try to write long, detailed chapters...'}
                  className="w-full h-40 sm:h-48 p-3 sm:p-4 bg-gray-50 border border-gray-100 rounded-2xl text-sm focus:ring-2 focus:ring-orange-100 outline-none transition-all resize-none"
                />
              </div>

              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-widest text-gray-400">Language / اللغة</span>
                  <div className="bg-gray-200 p-1 rounded-full flex gap-1">
                    <button 
                      onClick={() => setLanguage('ar')}
                      className={cn("px-3 sm:px-4 py-1.5 rounded-full text-[9px] sm:text-[10px] font-bold uppercase transition-all", language === 'ar' ? "bg-white shadow-sm text-black" : "opacity-40 hover:opacity-100")}
                    >Arabic</button>
                    <button 
                      onClick={() => setLanguage('en')}
                      className={cn("px-3 sm:px-4 py-1.5 rounded-full text-[9px] sm:text-[10px] font-bold uppercase transition-all", language === 'en' ? "bg-white shadow-sm text-black" : "opacity-40 hover:opacity-100")}
                    >English</button>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-2">
                  <button
                    onClick={handleGenerate}
                    disabled={isGenerating || !input.trim()}
                    className="w-full h-12 bg-orange-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-orange-700 transition-all shadow-lg shadow-orange-100 disabled:opacity-50"
                  >
                    {isGenerating ? <Loader2 className="animate-spin" /> : <Sparkles size={18} />}
                    {language === 'ar' ? 'توليد رواية إبداعية' : 'Generate Creative Novel'}
                  </button>

                  <button
                    onClick={handleDirectFormat}
                    disabled={isGenerating || !input.trim()}
                    className="w-full h-12 bg-white text-gray-700 border-2 border-gray-100 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-gray-50 transition-all disabled:opacity-50"
                  >
                    <FileText size={18} />
                    {language === 'ar' ? 'تنسيق مباشر للنص' : 'Direct Format Text'}
                  </button>
                </div>
              </div>

              <div className="mt-auto pt-4 sm:pt-6 border-t border-gray-50 space-y-4">
                 <div className="space-y-2">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                      {language === 'ar' ? 'تباعد الأسطر' : 'LINE HEIGHT'}
                    </span>
                    <input 
                      type="range" min="1" max="3" step="0.1" 
                      value={lineHeight} 
                      onChange={(e) => setLineHeight(Number(e.target.value))}
                      className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-orange-600"
                    />
                 </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Editor Area */}
        <section className="flex-1 overflow-y-auto p-4 sm:p-8 md:p-12 lg:p-20 bg-[#FDFCFB] relative">
          {/* Mobile Overlay for sidebar */}
          <AnimatePresence>
            {isSidebarOpen && window.innerWidth < 768 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsSidebarOpen(false)}
                className="absolute inset-0 z-30 bg-black/5backdrop-blur-[2px]"
              />
            )}
          </AnimatePresence>
          {/* Progress Bar UI */}
          <AnimatePresence>
            {isGenerating && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="absolute top-0 left-0 right-0 z-10 px-12 pt-4"
              >
                <div className="max-w-3xl mx-auto space-y-2">
                  <div className="flex justify-between items-center text-[10px] font-bold text-orange-600 uppercase tracking-widest">
                    <span>{language === 'ar' ? 'جاري تأليف الرواية...' : 'Crafting your novel...'}</span>
                    <span>{Math.round(progress)}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-orange-100 rounded-full overflow-hidden shadow-inner">
                    <motion.div 
                      className="h-full bg-orange-600 shadow-[0_0_10px_rgba(234,88,12,0.5)]"
                      initial={{ width: "0%" }}
                      animate={{ width: `${progress}%` }}
                      transition={{ ease: "linear" }}
                    />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <motion.div
            initial={false}
            animate={{ opacity: 1 }}
            className="max-w-3xl mx-auto"
          >
            {!content && !isGenerating && (
              <div className="h-[60vh] flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-16 h-16 bg-orange-50 rounded-full flex items-center justify-center text-orange-600">
                  <Plus size={32} />
                </div>
                <div>
                  <h2 className="text-xl font-serif font-bold">Start your masterpiece</h2>
                  <p className="text-gray-400 text-sm max-w-xs mx-auto">
                    {language === 'ar' 
                      ? 'أدخل فكرتك في القائمة الجانبية ودع الذكاء الاصطناعي يحولها لرواية'
                      : 'Enter your idea in the sidebar and let AI craft your novel.'}
                  </p>
                </div>
              </div>
            )}

            {isGenerating && (
              <div className="space-y-6 opacity-40 select-none pointer-events-none">
                <div className="h-12 bg-gray-200 rounded-lg w-3/4 animate-pulse" />
                <div className="space-y-3">
                  <div className="h-4 bg-gray-100 rounded w-full animate-pulse" />
                  <div className="h-4 bg-gray-100 rounded w-full animate-pulse" />
                  <div className="h-4 bg-gray-100 rounded w-5/6 animate-pulse" />
                </div>
                <div className="h-8 bg-gray-200 rounded-lg w-1/2 animate-pulse mt-12" />
                <div className="space-y-3">
                   <div className="h-4 bg-gray-100 rounded w-full animate-pulse" />
                   <div className="h-4 bg-gray-100 rounded w-full animate-pulse" />
                </div>
              </div>
            )}

            {content && (
              <div
                ref={editorRef}
                contentEditable={isEditable}
                suppressContentEditableWarning
                onBlur={(e) => setContent(e.currentTarget.innerHTML)}
                style={{
                  fontFamily: fontFamily,
                  fontSize: `${fontSize}px`,
                  textAlign: alignment,
                  fontWeight: isBold ? 'bold' : 'normal',
                  fontStyle: isItalic ? 'italic' : 'normal',
                  lineHeight: lineHeight,
                  direction: language === 'ar' ? 'rtl' : 'ltr'
                }}
                className="outline-none min-h-[80vh] prose-headings:font-serif prose-h1:text-4xl prose-h1:mb-8 prose-h2:text-2xl prose-h2:mt-12 prose-h2:mb-4 prose-p:mb-6"
                dangerouslySetInnerHTML={{ __html: content }}
              />
            )}
          </motion.div>
        </section>
      </main>
      
      {/* Arabic Font Import */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Amiri:ital,wght@0,400;0,700;1,400;1,700&family=Noto+Sans+Arabic:wght@400;700&family=Inter:wght@300;400;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }

        /* Basic HTML novel styling for the editor */
        div[contenteditable] h1 {
          font-size: 2em;
          border-bottom: 2px solid #eaeaea;
          padding-bottom: 0.5em;
          margin-bottom: 1em;
          text-align: center;
          margin-top: 0;
        }
        div[contenteditable] h2 {
          font-size: 1.5em;
          margin-top: 1.5em;
          margin-bottom: 0.75em;
          color: #c2410c;
          text-align: center;
        }
        div[contenteditable] p {
          margin-bottom: 1em;
          text-indent: 1.5em;
          text-align: justify;
        }

        @media print {
          header, aside, .progress-bar-container {
            display: none !important;
          }
          section {
            padding: 0 !important;
            margin: 0 !important;
            background: white !important;
            overflow: visible !important;
            display: block !important;
            height: auto !important;
          }
          body, .min-h-screen {
            background: white !important;
            height: auto !important;
          }
          .max-w-3xl {
            max-width: 100% !important;
          }
          div[contenteditable] {
            border: none !important;
            padding: 0 !important;
          }
        }
      `}</style>
    </div>
  );
}
