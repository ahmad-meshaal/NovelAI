import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenerativeAI } from "@google/generative-ai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Generation
  app.post("/api/generate", async (req, res) => {
    try {
      const { prompt, language } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey) {
        return res.status(500).json({ error: "API Key is missing on the server" });
      }

      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({ 
        model: "gemini-1.5-flash",
        systemInstruction: language === 'ar' 
          ? "أنت كاتب روايات محترف وعالمي. مهمتك هي تحويل الفكرة إلى رواية أدبية ملحمية واسعة الخيال. يجب أن يكون كل فصل طويلاً جداً ومفصلاً بشكل هائل (بحد أدنى 6000 حرف للفصل الواحد). لا تختصر أي حدث. استغرق في وصف المشاعر العميقة، الأماكن بالتفصيل الممل، الرؤى البصرية، والحوارات الفلسفية الطويلة. أريد تفاصيل دقيقة جداً تجعل القارئ يغرق في عالم الرواية. استخدم لغة عربية فصحى فخمة وساحرة. أخرج النص بتنسيق HTML (h1 للعنوان، h2 للفصول، p للفقرات)."
          : "You are a world-class professional novelist. Your task is to transform the idea into an epic, highly imaginative literary novel. Each chapter MUST be extremely long and immensely detailed (minimum 6000 characters per chapter). Never summarize any event. Indulge in describing deep emotions, settings in exquisite detail, visual visions, and long philosophical dialogues. I want very precise details that make the reader drown in the world of the novel. Use high-end, magical prose. Output the text in HTML format (h1 for the title, h2 for chapters, p for paragraphs)."
      });

      const result = await model.generateContentStream(prompt);
      
      // Stream the response to the client
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.setHeader('Transfer-Encoding', 'chunked');

      for await (const chunk of result.stream) {
        const chunkText = chunk.text();
        res.write(chunkText);
      }
      res.end();

    } catch (error) {
      console.error("Server Error:", error);
      res.status(500).send("Internal Server Error");
    }
  });

  // Vite integration for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer();
